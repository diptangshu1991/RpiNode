var api = {
  sum: function(a, b){
        return a + b;
    }
};

module.exports = api;